Original Mod:
https://www.nexusmods.com/fallout3/mods/4459